# Spotter Android Application

## What is City'In

Spotter is simply a place where tourists can meet local guides to share a moment or an activity during their trip.

## Team

The team is composed by four HETIC students, three developers and one designers.

## How to clone

Use the git clone command in your terminal :

``
git clone git@github.com:spottertrip/mobile.git
``


